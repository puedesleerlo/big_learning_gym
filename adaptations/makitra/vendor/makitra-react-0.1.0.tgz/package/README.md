# @makitra/react

React 18 components for Makitra, a kitchen-app design system. The components render the markup and `mk-` classes from `css/makitra.css`. There's no separate styling layer, so the CSS files below are required.

## Install

The package is private, so install it from this folder:

```sh
cd react
npm install
npm run build        # dist/index.js (ESM) and .d.ts files
```

Then depend on it from your app (for example `"@makitra/react": "file:../kitchen_design_sys/react"`). `react` and `react-dom` 18 or newer are peer dependencies.

## Required CSS and fonts

Load these once, in this order:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Geologica:slnt,wght,CRSV,SHRP@0,300..800,0,0..100&family=Protest+Guerrilla&display=swap">
<link rel="stylesheet" href="tokens/tokens.css">
<link rel="stylesheet" href="css/makitra.css">
```

Wrap your app in `class="mk-root"` (or put `class="mk"` on `<body>`) for the base font, colors and focus rings. Themes follow the OS. Stamp `data-theme="light"` or `data-theme="dark"` on `<html>` to force one.

Protest Guerrilla is Latin-only. Put `lang="uk"` on Ukrainian text and the display style switches to heavy Geologica.

## Example

```tsx
import * as React from 'react';
import { Button, IngredientList, RecipeCard, SegmentedControl, Stepper, type UnitSystem } from '@makitra/react';

const ingredients = [
  { id: 'beef', name: 'Beef on the bone', qty: 600, unit: 'g' },
  { id: 'beets', name: 'Beets', qty: 400, unit: 'g' },
  { id: 'oil', name: 'Sunflower oil', qty: 2, unit: 'tbsp' },
] as const;

export function Borshch() {
  const [servings, setServings] = React.useState(6);
  const [units, setUnits] = React.useState<UnitSystem>('metric');
  const [have, setHave] = React.useState<string[]>(['oil']);

  return (
    <div className="mk-root">
      <RecipeCard title="Borshch" nativeTitle="Борщ" tone="soup" image="assets/dishes/borshch.svg" duration="2 h" href="/recipes/borshch" />
      <Stepper label="Servings" value={servings} min={1} max={24} onChange={setServings} format={(n) => `${n} servings`} />
      <SegmentedControl legend="Units" options={[{ value: 'metric', label: 'Metric' }, { value: 'us', label: 'US' }]} value={units} onChange={setUnits} />
      <IngredientList
        ingredients={ingredients}
        servings={servings}
        baseServings={6}
        units={units}
        have={have}
        onHaveChange={(id, on) => setHave((h) => (on ? [...h, id] : h.filter((x) => x !== id)))}
      />
      <Button variant="primary" icon="bag">Add {ingredients.length - have.length} to shopping list</Button>
    </div>
  );
}
```

## Components

| Component | Key props |
| --- | --- |
| `Icon` | `name` (book, jar, bag, timer, clock, bowl, flame, leaf, scale, search, bookmark, check, plus, minus, play, pause, back, close), `size?`, `title?` (decorative without it) |
| `Motif` | `name` (beet, leaf, mushroom, poppy, daisy, spark, cherry, pepper), `m1?` `m2?` `m3?` colors, `title?` |
| `Button` | `variant?` primary, secondary, quiet or danger, `size?` md or lg, `icon?`, plus button props |
| `IconButton` | `icon`, `label`, `pressed?`, `onPressedChange?`, `variant?` |
| `Tag` | `tone?` neutral, success, warning or danger, `icon?` |
| `Chip`, `ChipGroup` | `pressed`, `onPressedChange`. The group takes `label` |
| `TextField` | `label`, `help?`, `error?` (sets aria-invalid and aria-describedby), plus input props |
| `SearchField` | `label` (visually hidden, also the default placeholder), plus input props |
| `Checkbox` | `checked`, `onCheckedChange`, `children` |
| `Switch` | `checked`, `onCheckedChange`, `children` (role="switch") |
| `SegmentedControl` | `legend`, `options: {value, label}[]`, `value`, `onChange`, `name?` |
| `Stepper` | `label`, `value`, `min?`, `max?`, `onChange`, `format?`, `decrementLabel?`, `incrementLabel?` |
| `Display` | `as?` (default h2), `size?` xl to 5xl, `lang?`, `className?` |
| `Patch` | `tone` soup, preserve, garden, dough, drink or cellar, `cut?` patch, plate or tag, `as?` |
| `Meta` | `items: {icon?, label}[]` |
| `RecipeCard` | `title`, `nativeTitle?`, `image?` (URL or element), `imageAlt?`, `tone`, `cut?`, `duration`, `servings?`, `saved?`, `onSavedChange?`, `onOpen?`, `href?`, `compact?`, `titleAs?` |
| `IngredientList` | `ingredients: {id, name, qty, unit}[]`, `servings`, `baseServings`, `units` metric or us, `have` (Set or array of ids), `onHaveChange(id, have)` |
| `MethodStep` | `number`, `children`, `actions?` |
| `TimerDial` | `total`, `remaining` (seconds), `state` running, paused or done, `label?`, `children?` for controls |
| `PantryRow`, `PantryList` | `name`, `amount?`, `status` in-stock, use-soon, past-date or low, `statusLabel?`, `tone?` |
| `Toast`, `ToastRegion` | `children`, `action?: {label, onClick}`. Keep the region mounted and swap toasts inside it |
| `TabBar` | `items: {id, label, icon}[]`, `current`, `onSelect`, `label` |
| `EmptyState` | `art?`, `title`, `children`, `action?`, `titleAs?` |
| `CookMode` | `children`, `className?` |

Hooks and helpers:

- `useCountdown(totalSeconds, { initialRemaining?, onDone? })` returns `{ remaining, running, done, start, pause, reset }`. Starting a finished countdown begins again from the total.
- `formatQuantity(ingredient, scale, units)` scales and converts: g/kg to oz/lb, l/ml to cups/qt, tbsp to the nearest ½, whole cloves, with ¼ ½ ¾ glyphs.
- `formatClock(seconds)` returns `m:ss`.

`css/makitra.css` ends with a small appended block for this package: `.mk-tabbar button`, `button.mk-recipe-card__link`, `.mk-recipe-card__art img` and `.mk-chip-group`.

## Demo: "Try the app"

A phone-sized prototype with Recipes, Recipe, Cook mode, Pantry, Shopping and Timers. Build it with `npm run build:demo`, then open `demo/index.html`.

To embed it in a page:

```html
<link rel="stylesheet" href="tokens/tokens.css">
<link rel="stylesheet" href="css/makitra.css">
<link rel="stylesheet" href="react/demo/demo.css">
<!-- plus the Google Fonts link above -->

<div id="makitra-demo" class="phone" data-assets="assets/">
  <!-- static no-JS fallback; React replaces it -->
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js"></script>
<script src="react/dist/makitra-demo.js"></script>
```

- `.phone` must be a fixed-size flex column with `overflow: hidden` (see `demo/index.html`).
- `data-assets` is the base URL for `dishes/*.svg`. It defaults to `assets/`.
- `data-start` is optional and opens a screen directly, which helps with screenshots: `recipe:borshch`, `cook:borshch:4`, `finish:borshch`, `pantry`, `shopping` or `timers`.

## Scripts

- `npm run typecheck` runs `tsc --noEmit` over `src` and `demo`.
- `npm run build` builds the library to `dist/index.js` with React external, plus `.d.ts` files.
- `npm run build:demo` builds `dist/makitra-demo.js` as a minified IIFE. React comes from `window.React` and `window.ReactDOM`.
- `npm run build:all` runs both.

Every TSX file uses the classic runtime (`"jsx": "react"` with `import * as React from 'react'`). The demo build fails if anything imports `react/jsx-runtime`.

## Credits

Visual direction inspired by Ukrainian food and cuisine illustration by Anna Riabchenko (https://www.behance.net/gallery/209955313/Ukrainian-food-and-cuisine-illustration). Non-commercial use.

Typefaces: Protest Guerrilla by Octavio Pardo and Geologica by Monokrom, both under the SIL Open Font License.
