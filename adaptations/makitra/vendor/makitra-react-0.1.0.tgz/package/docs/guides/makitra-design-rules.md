# Makitra design rules

Makitra is a kitchen-app design system: flat cut-paper shapes, colors sampled from a Ukrainian table, and type you can read from the stove. Visual direction inspired by "Ukrainian food and cuisine illustration" by Anna Riabchenko (Behance). Non-commercial use.

## Color
- Style with role tokens, never raw hex: `--mk-bg` (page), `--mk-surface` (cards, rows, inputs), `--mk-sunken` (wells, steppers), `--mk-text`, `--mk-text-muted`, `--mk-line` (dividers), `--mk-line-strong` (control edges), `--mk-action` / `--mk-on-action` (primary button), `--mk-link`, `--mk-selected` / `--mk-on-selected`, `--mk-focus`.
- Status colors come in pairs: `--mk-success` + `--mk-success-bg`, `--mk-warning` + `--mk-warning-bg`, `--mk-danger` + `--mk-danger-bg`. Status is always word + color + icon, never color alone.
- No shadows, no gradients, no borders around cards. Separate things by color: a card is `--mk-surface` on `--mk-bg`.
- Pigments (`--mk-paprika`, `--mk-enamel`, `--mk-garden`, `--mk-marigold`, `--mk-plum`, `--mk-cornflower`) are for illustration and category patches. Paprika is 3.6:1 on paper: shapes and display type 24px+ only.
- Category patches: soup → `--mk-patch-soup` (paprika), dough → `--mk-patch-dough` (marigold), preserve → `--mk-patch-preserve` (enamel), garden → `--mk-patch-garden` (green), drink → `--mk-patch-drink` (cornflower), cellar → `--mk-patch-cellar` (plum). Pair each with its `--mk-on-patch-*` text color.
- Both themes (day and night) come from the same tokens. Cook mode (`CookMode`, class `mk-cook`) stays dark in both.

## Type
- `Display` (Protest Guerrilla, uppercase) is only for dish names, screen titles and big numbers, 27px and up. Never body copy.
- Everything else is Geologica: body 17px (`--mk-text-md`), step text 21px (`--mk-text-lg`), meta 14px (`--mk-text-sm`).
- Ukrainian text gets `lang="uk"`; display styles then switch to heavy Geologica because Protest Guerrilla has no Cyrillic.

## Shape and layout
- Controls use uneven "nick" radii (`--mk-nick-xs|sm|md|lg`). Decorative grounds use polygon cuts (`--mk-cut-patch|plate|tag`) through `Patch`. Never clip anything focusable.
- Touch targets are at least 48px (`--mk-touch`). Space on the 4px scale `--mk-space-1` … `--mk-space-9`; lay out with flex/grid `gap`.
- One primary button per screen.

## Words
- Sentence case, active voice. Buttons say what happens ("Add 9 to shopping list"); the toast repeats it ("Added 9 ingredients to Shopping.").
- Real kitchen units (g, kg, ml, l, tbsp, tsp, cloves, °C) and short dates ("12 Sep").
- Dish names transliterated (Borshch, Varenyky, Deruny, Holubtsi, Uzvar, Pampushky) with the Ukrainian name underneath in `lang="uk"`.

## Illustration and motion
- Use `Motif` shapes and the Makitra drawings. New drawings: flat polygons with straight scissor edges, 2–4 pigments, no outlines, no gradients, no text.
- Motion confirms what the hands did (press, tick, toggle). Only a running timer moves on its own. Respect reduced motion.
