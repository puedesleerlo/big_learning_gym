/**
 * Ingredient scaling and unit conversion. Ported from the reference page
 * (index.html, "Ingredients" component) with the same rounding rules:
 *  - g:     metric rounds to 5 g under 50 g, to 10 g above, and switches to kg at 1000 g.
 *           US converts to oz (nearest ¼), or lb (one decimal) from 16 oz.
 *  - l:     metric shows ml (nearest 50) under 1 l, litres (one decimal) above.
 *           US converts to cups (nearest ¼), or quarts from 4 cups.
 *  - tbsp:  nearest ½ tablespoon, never less than ½.
 *  - clove: whole cloves, never less than 1.
 * Extra units used by the demo recipes follow the closest rule:
 *  ml is converted to litres first, tsp follows tbsp, piece follows clove.
 */

export type Unit = 'g' | 'l' | 'ml' | 'tbsp' | 'tsp' | 'clove' | 'piece' | 'to-taste';
export type UnitSystem = 'metric' | 'us';

export interface Ingredient {
  id: string;
  name: string;
  qty: number;
  unit: Unit;
}

const FRACTIONS: Record<string, string> = { '0': '', '0.25': '¼', '0.5': '½', '0.75': '¾' };

/** Rounds to the nearest quarter (at least ¼) and writes it with fraction glyphs: 1¾, ½. */
export function fraction(value: number): string {
  const q = Math.max(0.25, Math.round(value * 4) / 4);
  const whole = Math.floor(q);
  return `${whole || ''}${FRACTIONS[String(q - whole)]}` || '0';
}

/** One decimal place at most, without a trailing ".0". */
export function trimDecimal(value: number): string {
  return String(Math.round(value * 10) / 10);
}

function formatGrams(v: number, us: boolean): string {
  if (us) {
    const oz = v / 28.35;
    return oz >= 16 ? `${trimDecimal(oz / 16)} lb` : `${fraction(oz)} oz`;
  }
  if (v >= 1000) return `${trimDecimal(v / 1000)} kg`;
  return `${v < 50 ? Math.max(5, Math.round(v / 5) * 5) : Math.round(v / 10) * 10} g`;
}

function formatLitres(v: number, us: boolean): string {
  if (us) {
    const cups = v * 4.227;
    return cups >= 4 ? `${fraction(v * 1.057)} qt` : `${fraction(cups)} ${cups < 1.2 ? 'cup' : 'cups'}`;
  }
  return v < 1 ? `${Math.round((v * 1000) / 50) * 50} ml` : `${trimDecimal(v)} l`;
}

/**
 * Formats an ingredient quantity for display.
 * @param ingredient the quantity and unit at base servings
 * @param scale servings / baseServings
 * @param units 'metric' or 'us'
 */
export function formatQuantity(
  ingredient: Pick<Ingredient, 'qty' | 'unit'>,
  scale: number,
  units: UnitSystem,
): string {
  const v = ingredient.qty * scale;
  const us = units === 'us';
  switch (ingredient.unit) {
    case 'g':
      return formatGrams(v, us);
    case 'l':
      return formatLitres(v, us);
    case 'ml':
      return formatLitres(v / 1000, us);
    case 'tbsp':
      return `${fraction(Math.max(0.5, Math.round(v * 2) / 2))} tbsp`;
    case 'tsp':
      return `${fraction(Math.max(0.5, Math.round(v * 2) / 2))} tsp`;
    case 'clove': {
      const c = Math.max(1, Math.round(v));
      return `${c} ${c === 1 ? 'clove' : 'cloves'}`;
    }
    case 'piece':
      return String(Math.max(1, Math.round(v)));
    case 'to-taste':
      return 'to taste';
  }
}

/** Formats seconds as m:ss, the way the timer readout does. */
export function formatClock(seconds: number): string {
  const s = Math.max(0, Math.round(seconds));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}
