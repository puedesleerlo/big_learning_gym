import * as React from 'react';

export interface CountdownOptions {
  /** Seconds left when the hook mounts. Defaults to the total. */
  initialRemaining?: number;
  /** Called once when the countdown reaches zero. */
  onDone?: () => void;
}

export interface Countdown {
  /** Whole seconds left. */
  remaining: number;
  running: boolean;
  /** True when remaining is 0. */
  done: boolean;
  /** Starts or resumes. Starting a finished countdown begins again from the total. */
  start: () => void;
  pause: () => void;
  /** Stops and returns to the total. */
  reset: () => void;
}

/**
 * A seconds countdown with the same behaviour as the reference timer:
 * it ticks down once a second, stops at zero, "start" on a finished timer
 * begins again, and "reset" stops it at the full time.
 * It measures against the clock, so it stays accurate in background tabs.
 */
export function useCountdown(totalSeconds: number, options: CountdownOptions = {}): Countdown {
  const total = Math.max(0, Math.round(totalSeconds));
  const initial = Math.min(total, Math.max(0, Math.round(options.initialRemaining ?? total)));

  const [remaining, setRemaining] = React.useState(initial);
  const [running, setRunning] = React.useState(false);

  const remainingRef = React.useRef(initial);
  const endsAtRef = React.useRef<number | null>(null);
  const totalRef = React.useRef(total);
  const onDoneRef = React.useRef(options.onDone);

  React.useEffect(() => {
    totalRef.current = total;
    onDoneRef.current = options.onDone;
  });

  const commit = React.useCallback((value: number) => {
    remainingRef.current = value;
    setRemaining(value);
  }, []);

  const secondsLeft = () => (endsAtRef.current === null ? remainingRef.current : Math.max(0, Math.ceil((endsAtRef.current - Date.now()) / 1000)));

  React.useEffect(() => {
    if (!running) return undefined;
    const id = window.setInterval(() => {
      if (endsAtRef.current === null) return;
      const left = secondsLeft();
      if (left !== remainingRef.current) commit(left);
      if (left === 0) {
        endsAtRef.current = null;
        setRunning(false);
        onDoneRef.current?.();
      }
    }, 250);
    return () => window.clearInterval(id);
  }, [running, commit]);

  const start = React.useCallback(() => {
    if (endsAtRef.current !== null) return;
    const from = remainingRef.current === 0 ? totalRef.current : remainingRef.current;
    if (from === 0) return;
    commit(from);
    endsAtRef.current = Date.now() + from * 1000;
    setRunning(true);
  }, [commit]);

  const pause = React.useCallback(() => {
    if (endsAtRef.current === null) return;
    const left = secondsLeft();
    endsAtRef.current = null;
    commit(left);
    setRunning(false);
  }, [commit]);

  const reset = React.useCallback(() => {
    endsAtRef.current = null;
    commit(totalRef.current);
    setRunning(false);
  }, [commit]);

  return { remaining, running, done: remaining === 0, start, pause, reset };
}
