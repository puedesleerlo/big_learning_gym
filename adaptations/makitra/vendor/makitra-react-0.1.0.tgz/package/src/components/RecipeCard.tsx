import * as React from 'react';
import { cx } from '../lib/cx';
import { IconButton } from './Button';
import { Meta, type MetaItem } from './Meta';
import { Patch, type PatchCut, type PatchTone } from './Patch';

export interface RecipeCardProps extends Omit<React.HTMLAttributes<HTMLElement>, 'title'> {
  title: string;
  /** Ukrainian name, shown under the title with lang="uk". */
  nativeTitle?: string;
  /** Image URL, or your own illustration element. */
  image?: string | React.ReactNode;
  /** Alt text for an image URL. Defaults to empty, since the title already names the dish. */
  imageAlt?: string;
  tone: PatchTone;
  cut?: PatchCut;
  /** Total time, such as "2 h". */
  duration: React.ReactNode;
  /** Such as "6 servings". */
  servings?: React.ReactNode;
  saved?: boolean;
  /** Shows the Save toggle when provided. */
  onSavedChange?: (saved: boolean) => void;
  /** Opens the recipe. Used as a button click, or alongside href. */
  onOpen?: (event: React.MouseEvent<HTMLElement>) => void;
  /** Makes the card a link. Without it the card is a button. */
  href?: string;
  compact?: boolean;
  /** Heading element for the title. Defaults to h3. */
  titleAs?: 'h2' | 'h3' | 'h4' | 'p';
}

/**
 * An illustration on its category patch, the dish name and its Ukrainian name.
 * The whole card is one link or button (stretched with ::after). Save is a separate button.
 */
export function RecipeCard({
  title,
  nativeTitle,
  image,
  imageAlt,
  tone,
  cut,
  duration,
  servings,
  saved = false,
  onSavedChange,
  onOpen,
  href,
  compact = false,
  titleAs: TitleTag = 'h3',
  className,
  ...rest
}: RecipeCardProps) {
  const meta: MetaItem[] = [{ key: 'time', icon: 'clock', label: duration }];
  if (servings !== undefined && servings !== null) meta.push({ key: 'servings', icon: 'bowl', label: servings });

  return (
    <article className={cx('mk-recipe-card', compact && 'mk-recipe-card--compact', className)} {...rest}>
      <Patch tone={tone} cut={cut} className="mk-recipe-card__art">
        {typeof image === 'string' ? <img src={image} alt={imageAlt ?? ''} /> : image}
      </Patch>
      <div className="mk-recipe-card__body">
        <TitleTag className="mk-recipe-card__title mk-display">
          {href !== undefined ? (
            <a className="mk-recipe-card__link" href={href} onClick={onOpen}>
              {title}
            </a>
          ) : (
            <button type="button" className="mk-recipe-card__link" onClick={onOpen}>
              {title}
            </button>
          )}
        </TitleTag>
        {nativeTitle ? (
          <p className="mk-native" lang="uk">
            {nativeTitle}
          </p>
        ) : null}
        <Meta items={meta} />
      </div>
      {onSavedChange ? (
        <IconButton
          className="mk-recipe-card__save"
          icon="bookmark"
          label={`Save ${title}`}
          pressed={saved}
          onPressedChange={onSavedChange}
        />
      ) : null}
    </article>
  );
}
