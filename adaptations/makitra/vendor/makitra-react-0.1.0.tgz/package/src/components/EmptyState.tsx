import * as React from 'react';
import { cx } from '../lib/cx';

export interface EmptyStateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  /** Illustration. Give it the class mk-empty__art. */
  art?: React.ReactNode;
  title: React.ReactNode;
  /** Heading element for the title. Defaults to h2. */
  titleAs?: 'h2' | 'h3' | 'h4' | 'p';
  /** Names the next step. */
  children?: React.ReactNode;
  /** A button that takes that step. */
  action?: React.ReactNode;
}

/** An empty list that names the next step: a cut-paper illustration, a display title, one line of help and one action. */
export function EmptyState({ art, title, titleAs: TitleTag = 'h2', children, action, className, ...rest }: EmptyStateProps) {
  return (
    <div className={cx('mk-empty', className)} {...rest}>
      {art}
      <TitleTag className="mk-empty__title mk-display">{title}</TitleTag>
      {children ? <p>{children}</p> : null}
      {action}
    </div>
  );
}
