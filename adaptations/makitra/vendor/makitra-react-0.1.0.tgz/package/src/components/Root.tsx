import * as React from 'react';
import { cx } from '../lib/cx';

export interface MakitraRootProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
}

/**
 * The Makitra root. Wrap every screen in it: it paints the page ground (--mk-bg), sets the text color,
 * Geologica and the 17px body size. Without it, component text falls back to the browser font.
 */
export function MakitraRoot({ className, children, ...rest }: MakitraRootProps) {
  return (
    <div className={cx('mk-root', className)} {...rest}>
      {children}
    </div>
  );
}
