import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon } from './Icon';

export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'checked' | 'defaultChecked' | 'children' | 'className'> {
  checked: boolean;
  onCheckedChange?: (checked: boolean) => void;
  /** The label. Inside an ingredient list, pass the name and a .mk-qty span. */
  children: React.ReactNode;
  /** Class for the wrapping label. */
  className?: string;
}

/** A 48px-tall checkbox row: ingredients you have, shopping items you've picked up. */
export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  { checked, onCheckedChange, onChange, id, className, children, ...rest },
  ref,
) {
  const autoId = React.useId();
  const inputId = id ?? autoId;
  return (
    <label className={cx('mk-check', className)} htmlFor={inputId}>
      <input
        ref={ref}
        type="checkbox"
        id={inputId}
        checked={checked}
        onChange={(event) => {
          onChange?.(event);
          onCheckedChange?.(event.target.checked);
        }}
        {...rest}
      />
      <span className="mk-check__box" aria-hidden="true">
        <Icon name="check" />
      </span>
      <span className="mk-check__text">{children}</span>
    </label>
  );
});
