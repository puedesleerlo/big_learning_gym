import * as React from 'react';
import { cx } from '../lib/cx';

export interface SwitchProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'role' | 'checked' | 'defaultChecked' | 'children' | 'className'> {
  checked: boolean;
  onCheckedChange?: (checked: boolean) => void;
  children: React.ReactNode;
  className?: string;
}

/** An on/off setting that applies right away, with no save button. */
export const Switch = React.forwardRef<HTMLInputElement, SwitchProps>(function Switch(
  { checked, onCheckedChange, onChange, id, className, children, ...rest },
  ref,
) {
  const autoId = React.useId();
  const inputId = id ?? autoId;
  return (
    <label className={cx('mk-switch', className)} htmlFor={inputId}>
      <input
        ref={ref}
        type="checkbox"
        role="switch"
        id={inputId}
        checked={checked}
        onChange={(event) => {
          onChange?.(event);
          onCheckedChange?.(event.target.checked);
        }}
        {...rest}
      />
      <span className="mk-switch__track" aria-hidden="true" />
      <span>{children}</span>
    </label>
  );
});
