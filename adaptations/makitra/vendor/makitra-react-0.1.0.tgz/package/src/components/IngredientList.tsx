import * as React from 'react';
import { cx } from '../lib/cx';
import { formatQuantity, type Ingredient, type UnitSystem } from '../lib/units';
import { Checkbox } from './Checkbox';

export interface IngredientListProps<T extends Ingredient = Ingredient>
  extends Omit<React.HTMLAttributes<HTMLUListElement>, 'children'> {
  ingredients: ReadonlyArray<T>;
  servings: number;
  baseServings: number;
  units: UnitSystem;
  /** Ids of ingredients you already have (ticked). */
  have: ReadonlySet<string> | ReadonlyArray<string>;
  onHaveChange: (id: string, have: boolean) => void;
}

/** Ingredients scaled to the servings and converted to the unit system. A tick means "I have it". */
export function IngredientList<T extends Ingredient = Ingredient>({
  ingredients,
  servings,
  baseServings,
  units,
  have,
  onHaveChange,
  className,
  ...rest
}: IngredientListProps<T>) {
  const haveSet = React.useMemo(() => (have instanceof Set ? have : new Set(have)), [have]);
  const scale = baseServings > 0 ? servings / baseServings : 1;
  return (
    <ul className={cx('mk-ingredients', className)} {...rest}>
      {ingredients.map((ingredient) => (
        <li key={ingredient.id}>
          <Checkbox checked={haveSet.has(ingredient.id)} onCheckedChange={(checked) => onHaveChange(ingredient.id, checked)}>
            <span>{ingredient.name}</span>
            <span className="mk-qty">{formatQuantity(ingredient, scale, units)}</span>
          </Checkbox>
        </li>
      ))}
    </ul>
  );
}
