import * as React from 'react';
import { cx } from '../lib/cx';

export interface SegmentedOption<T extends string = string> {
  value: T;
  label: React.ReactNode;
}

export interface SegmentedControlProps<T extends string = string> {
  /** Group name for assistive tech, visually hidden. */
  legend: string;
  /** Radio group name. Generated when omitted. */
  name?: string;
  options: ReadonlyArray<SegmentedOption<T>>;
  value: T;
  onChange: (value: T) => void;
  className?: string;
  disabled?: boolean;
}

/** A radio group drawn as a row of segments (Metric / US, All / Use soon). */
export function SegmentedControl<T extends string = string>({
  legend,
  name,
  options,
  value,
  onChange,
  className,
  disabled,
}: SegmentedControlProps<T>) {
  const autoId = React.useId();
  const groupName = name ?? autoId;
  return (
    <fieldset className={cx('mk-segmented', className)} disabled={disabled}>
      <legend className="mk-visually-hidden">{legend}</legend>
      {options.map((option) => {
        const optionId = `${autoId}-${option.value}`;
        return (
          <label key={option.value} htmlFor={optionId}>
            <input
              type="radio"
              id={optionId}
              name={groupName}
              value={option.value}
              checked={option.value === value}
              onChange={() => onChange(option.value)}
            />
            <span>{option.label}</span>
          </label>
        );
      })}
    </fieldset>
  );
}
