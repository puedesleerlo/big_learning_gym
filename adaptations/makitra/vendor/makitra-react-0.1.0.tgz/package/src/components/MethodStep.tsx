import * as React from 'react';
import { cx } from '../lib/cx';

export interface MethodStepProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
  number: number;
  /** The instruction. */
  children: React.ReactNode;
  /** Buttons or tags under the text, such as a timer button. */
  actions?: React.ReactNode;
}

/** A numbered method step. Steps are numbered because order matters. */
export function MethodStep({ number, children, actions, className, ...rest }: MethodStepProps) {
  return (
    <div className={cx('mk-step', className)} {...rest}>
      <span className="mk-step__n" aria-hidden="true">
        {number}
      </span>
      <p className="mk-step__text">
        <span className="mk-visually-hidden">Step {number}: </span>
        {children}
      </p>
      {actions ? <div className="mk-step__actions">{actions}</div> : null}
    </div>
  );
}
