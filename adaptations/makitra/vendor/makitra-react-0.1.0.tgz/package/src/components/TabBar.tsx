import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon, type IconName } from './Icon';

export interface TabBarItem<T extends string = string> {
  id: T;
  label: string;
  icon: IconName;
}

export interface TabBarProps<T extends string = string> extends Omit<React.HTMLAttributes<HTMLElement>, 'onSelect'> {
  items: ReadonlyArray<TabBarItem<T>>;
  current: T;
  onSelect: (id: T) => void;
  /** Accessible name for the navigation, such as "App sections". */
  label: string;
}

/** Four places to go. The current tab gets a plum cut-out behind its icon. */
export function TabBar<T extends string = string>({ items, current, onSelect, label, className, ...rest }: TabBarProps<T>) {
  return (
    <nav className={cx('mk-tabbar', className)} aria-label={label} {...rest}>
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          aria-current={item.id === current ? 'page' : undefined}
          onClick={() => onSelect(item.id)}
        >
          <span className="mk-tabbar__icon">
            <Icon name={item.icon} />
          </span>
          {item.label}
        </button>
      ))}
    </nav>
  );
}
