import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon, type IconName } from './Icon';

export type TagTone = 'neutral' | 'success' | 'warning' | 'danger';

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: TagTone;
  icon?: IconName;
}

/** A static label that describes a recipe or an item. It can't be pressed. */
export function Tag({ tone = 'neutral', icon, className, children, ...rest }: TagProps) {
  return (
    <span className={cx('mk-tag', tone !== 'neutral' && `mk-tag--${tone}`, className)} {...rest}>
      {icon ? <Icon name={icon} /> : null}
      {children}
    </span>
  );
}
