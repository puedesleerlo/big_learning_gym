import * as React from 'react';
import { cx } from '../lib/cx';
import { illustrations } from './illustrations.generated';

export type IllustrationName = keyof typeof illustrations;

export interface IllustrationProps extends Omit<React.SVGProps<SVGSVGElement>, 'name' | 'ref' | 'children' | 'dangerouslySetInnerHTML'> {
  /**
   * Dishes: borshch, varenyky, deruny, holubtsi, uzvar, pampushky (place them on their category Patch).
   * Ingredients: beet, carrot, potato, onion, garlic, cabbage, tomato, dill, cucumber, mushroom, cherries, sunflower-oil, pepper-grinder.
   * Empty states: empty-shopping, empty-pantry, empty-timers. Brand: makitra-bowl.
   */
  name: IllustrationName;
  /** Accessible name. Without it the drawing is decorative (aria-hidden). Pass the built-in title with `title={true}`. */
  title?: string | boolean;
}

/**
 * A Makitra cut-paper drawing as inline SVG: flat polygons, 2–4 pigments, no outlines.
 * Fills the width of its container. Use it for recipe card art, ingredient rows, empty states and heroes.
 */
export function Illustration({ name, title, className, ...rest }: IllustrationProps) {
  const art = illustrations[name];
  const label = title === true ? art.title : typeof title === 'string' ? title : undefined;
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox={art.viewBox}
      className={cx('mk-illustration', className)}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      focusable="false"
      {...rest}
      dangerouslySetInnerHTML={{ __html: art.body }}
    />
  );
}

export const illustrationNames = Object.keys(illustrations) as IllustrationName[];
