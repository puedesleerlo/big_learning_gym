import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon, type IconName } from './Icon';
import { Tag, type TagTone } from './Tag';
import type { PatchTone } from './Patch';

export type PantryStatus = 'in-stock' | 'use-soon' | 'past-date' | 'low';
/** Jar color: a category patch, or plain bright paper. */
export type PantryTone = PatchTone | 'paper';

const STATUS: Record<PantryStatus, { tone: TagTone; icon: IconName; label: string }> = {
  'in-stock': { tone: 'success', icon: 'check', label: 'In stock' },
  'use-soon': { tone: 'warning', icon: 'clock', label: 'Use soon' },
  'past-date': { tone: 'danger', icon: 'close', label: 'Past date' },
  low: { tone: 'neutral', icon: 'scale', label: 'Running low' },
};

function jarStyle(tone: PantryTone): React.CSSProperties {
  return (
    tone === 'paper'
      ? { '--patch': 'var(--mk-paper-bright)', '--on-patch': 'var(--mk-plum-900)' }
      : { '--patch': `var(--mk-patch-${tone})`, '--on-patch': `var(--mk-on-patch-${tone})` }
  ) as React.CSSProperties;
}

export interface PantryRowProps extends Omit<React.LiHTMLAttributes<HTMLLIElement>, 'children'> {
  name: React.ReactNode;
  /** Such as "300 g, opened 9 Sep". */
  amount?: React.ReactNode;
  status: PantryStatus;
  /** Overrides the status word, such as "Use in 2 days". */
  statusLabel?: React.ReactNode;
  tone?: PantryTone;
}

/** A pantry item. Status always uses a word, a color and an icon together. Render inside PantryList. */
export function PantryRow({ name, amount, status, statusLabel, tone = 'dough', className, ...rest }: PantryRowProps) {
  const s = STATUS[status];
  return (
    <li className={cx('mk-pantry-row', className)} data-status={status} {...rest}>
      <span className="mk-pantry-row__jar mk-patch" style={jarStyle(tone)}>
        <Icon name="jar" />
      </span>
      <span>
        <span className="mk-pantry-row__name">{name}</span>
        {amount ? <span className="mk-pantry-row__amount">{amount}</span> : null}
      </span>
      <Tag tone={s.tone} icon={s.icon}>
        {statusLabel ?? s.label}
      </Tag>
    </li>
  );
}

export type PantryListProps = React.HTMLAttributes<HTMLUListElement>;

export function PantryList({ className, ...rest }: PantryListProps) {
  return <ul className={cx('mk-pantry', className)} {...rest} />;
}
