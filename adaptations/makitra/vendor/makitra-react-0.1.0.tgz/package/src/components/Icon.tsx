import * as React from 'react';
import { cx } from '../lib/cx';

export const iconNames = [
  'book', 'jar', 'bag', 'timer', 'clock', 'bowl', 'flame', 'leaf', 'scale',
  'search', 'bookmark', 'check', 'plus', 'minus', 'play', 'pause', 'back', 'close',
] as const;

export type IconName = (typeof iconNames)[number];

/* Geometry copied from the i-* symbols in index.html: 24×24, straight segments.
   .mk-icon supplies the stroke, square caps and miter joins. */
const shapes: Record<IconName, React.ReactNode> = {
  clock: (
    <>
      <polygon points="12,3 18.4,5.5 21,12 18.4,18.5 12,21 5.6,18.5 3,12 5.6,5.5" />
      <polyline points="12,7.5 12,12 15.5,14.5" />
    </>
  ),
  bowl: (
    <>
      <polygon points="3,10.5 21,10.5 18.5,17 14.5,19.5 9.5,19.5 5.5,17" />
      <path d="M8.5 22h7M9 3l1.3 2L9 7M14 3l1.3 2L14 7" />
    </>
  ),
  flame: <polygon points="12,2.5 16.5,8 15.5,11 18.5,12.5 18,18 12,21.5 6,18 5.5,12.5 9,9.5 9.5,6" />,
  leaf: (
    <>
      <polygon points="4.5,19.5 5.5,10 12,4 20,3.5 19.5,11.5 13.5,18" />
      <path d="M4.5 19.5L13 11" />
    </>
  ),
  search: (
    <>
      <polygon points="10.5,3.5 15.4,5.5 17.5,10.5 15.4,15.4 10.5,17.5 5.6,15.4 3.5,10.5 5.6,5.5" />
      <path d="M15.8 15.8l4.7 4.7" />
    </>
  ),
  bookmark: <polygon points="6,3 18,3 18,21 12,16.5 6,21" />,
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  check: <polyline points="4.5,12.5 9.5,17.5 19.5,6.5" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  back: (
    <>
      <polyline points="11,5 4,12 11,19" />
      <path d="M4.5 12H20" />
    </>
  ),
  play: <polygon points="7,4.5 19,12 7,19.5" />,
  pause: <path d="M8 5v14M16 5v14" />,
  timer: (
    <>
      <polygon points="12,6 17,8 19,13 17,18 12,20 7,18 5,13 7,8" />
      <path d="M9.5 2.5h5M12 2.5V6M12 13l3-3" />
    </>
  ),
  jar: (
    <>
      <path d="M7 3h10v3.5H7z" />
      <polygon points="6,9 18,9 19,21 5,21" />
      <path d="M9 14h6" />
    </>
  ),
  bag: (
    <>
      <polyline points="8,9 9.5,3.5 14.5,3.5 16,9" />
      <polygon points="3.5,9 20.5,9 18,21 6,21" />
      <path d="M8 13l4 4 4-4" />
    </>
  ),
  book: (
    <>
      <polygon points="3,4.5 11,6 11,20.5 3,19" />
      <polygon points="21,4.5 13,6 13,20.5 21,19" />
    </>
  ),
  scale: (
    <>
      <path d="M6 5.5h12M12 5.5V9" />
      <polygon points="5,9 19,9 20.5,20.5 3.5,20.5" />
      <polyline points="9.5,15.5 12,13 14.5,15.5" />
    </>
  ),
};

export interface IconProps extends Omit<React.SVGProps<SVGSVGElement>, 'name' | 'ref'> {
  name: IconName;
  /** Width and height. Numbers are pixels. Leave unset to let the component CSS size it. */
  size?: number | string;
  /** Accessible name. Without it the icon is decorative (aria-hidden). */
  title?: string;
}

/** One of 18 UI icons on a 24px grid: straight segments, square caps, octagons instead of circles. Uses currentColor. */
export function Icon({ name, size, title, className, style, ...rest }: IconProps) {
  const titleId = React.useId();
  const sizedStyle = size === undefined ? style : { width: size, height: size, ...style };
  const a11y = title ? { role: 'img', 'aria-labelledby': titleId } : { 'aria-hidden': true as const };
  return (
    <svg viewBox="0 0 24 24" className={cx('mk-icon', className)} style={sizedStyle} focusable="false" {...a11y} {...rest}>
      {title ? <title id={titleId}>{title}</title> : null}
      {shapes[name]}
    </svg>
  );
}
