import * as React from 'react';
import { cx } from '../lib/cx';
import { formatClock } from '../lib/units';

export type TimerState = 'running' | 'paused' | 'done';

/* The 16-sided ring from index.html: radius 100 around (120, 120), starting at 3 o'clock.
   The CSS rotates the svg -90deg so the ring empties from 12 o'clock. */
const RING_POINTS =
  '220.0,120.0 212.4,158.3 190.7,190.7 158.3,212.4 120.0,220.0 81.7,212.4 49.3,190.7 27.6,158.3 20.0,120.0 27.6,81.7 49.3,49.3 81.7,27.6 120.0,20.0 158.3,27.6 190.7,49.3 212.4,81.7';

const DEFAULT_LABELS: Record<TimerState, string> = {
  running: 'Running',
  paused: 'Paused',
  done: 'Done',
};

export interface TimerDialProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Full time in seconds. */
  total: number;
  /** Seconds left. */
  remaining: number;
  state: TimerState;
  /** Word under the time, such as "Simmering". Defaults to Running, Paused or Done. */
  label?: React.ReactNode;
  /** Controls rendered under the dial, such as Start and Reset buttons. */
  children?: React.ReactNode;
}

/** A 16-sided ring that empties as time runs out and turns into a full green ring when done. Pair it with useCountdown. */
export function TimerDial({ total, remaining, state, label, className, children, ...rest }: TimerDialProps) {
  // A finished timer shows a full ring in garden green, so "done" reads at a glance.
  const fraction = state === 'done' ? 1 : total > 0 ? Math.min(1, Math.max(0, remaining / total)) : 0;
  return (
    <div className={cx('mk-timer', className)} data-state={state} {...rest}>
      <div className="mk-timer__dial">
        <svg viewBox="0 0 240 240" aria-hidden="true" focusable="false">
          <polygon className="mk-timer__track" points={RING_POINTS} />
          <polygon
            className="mk-timer__fill"
            points={RING_POINTS}
            pathLength={100}
            strokeDasharray="100"
            style={{ strokeDashoffset: String(100 * (1 - fraction)) }}
          />
        </svg>
        <div className="mk-timer__readout">
          <span className="mk-timer__time" role="timer">
            {formatClock(remaining)}
          </span>
          <span className="mk-timer__label" aria-live="polite">
            {label ?? DEFAULT_LABELS[state]}
          </span>
        </div>
      </div>
      {children}
    </div>
  );
}
