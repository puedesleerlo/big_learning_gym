import * as React from 'react';
import { cx } from '../lib/cx';

export interface CookModeProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  className?: string;
}

/** A fixed night-kitchen scope with larger step text. Stays dark in both themes. */
export const CookMode = React.forwardRef<HTMLDivElement, CookModeProps>(function CookMode({ className, ...rest }, ref) {
  return <div ref={ref} className={cx('mk-cook', className)} {...rest} />;
});
