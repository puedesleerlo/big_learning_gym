import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon, type IconName } from './Icon';

export type ButtonVariant = 'primary' | 'secondary' | 'quiet' | 'danger';
export type ButtonSize = 'md' | 'lg';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Leave unset for the plain sunken button. */
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Icon shown before the label. */
  icon?: IconName;
}

/** A labelled button. The label says what happens: "Start cooking", not "Continue". */
export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant, size = 'md', icon, type = 'button', className, children, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cx('mk-btn', variant && `mk-btn--${variant}`, size === 'lg' && 'mk-btn--lg', className)}
      {...rest}
    >
      {icon ? <Icon name={icon} /> : null}
      {children}
    </button>
  );
});

export interface IconButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'aria-label' | 'aria-pressed'> {
  icon: IconName;
  /** Accessible name. For a toggle, keep it constant ("Save Borshch") and let pressed carry the state. */
  label: string;
  /** Makes the button a toggle (aria-pressed). A pressed icon fills in. */
  pressed?: boolean;
  onPressedChange?: (pressed: boolean) => void;
  variant?: ButtonVariant;
}

/** A 48px square icon-only button, optionally a toggle. */
export const IconButton = React.forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { icon, label, pressed, onPressedChange, variant, type = 'button', className, onClick, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cx('mk-btn', variant && `mk-btn--${variant}`, 'mk-btn--icon', className)}
      aria-label={label}
      aria-pressed={pressed}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented && pressed !== undefined) onPressedChange?.(!pressed);
      }}
      {...rest}
    >
      <Icon name={icon} />
    </button>
  );
});
