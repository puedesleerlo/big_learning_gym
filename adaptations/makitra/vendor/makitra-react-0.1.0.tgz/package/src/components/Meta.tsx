import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon, type IconName } from './Icon';

export interface MetaItem {
  icon?: IconName;
  label: React.ReactNode;
  key?: string;
}

export interface MetaProps extends Omit<React.HTMLAttributes<HTMLUListElement>, 'children'> {
  items: ReadonlyArray<MetaItem>;
}

/** A row of short facts: time, servings, heat. */
export function Meta({ items, className, ...rest }: MetaProps) {
  return (
    <ul className={cx('mk-meta', className)} {...rest}>
      {items.map((item, index) => (
        <li key={item.key ?? index}>
          {item.icon ? <Icon name={item.icon} /> : null}
          {item.label}
        </li>
      ))}
    </ul>
  );
}
