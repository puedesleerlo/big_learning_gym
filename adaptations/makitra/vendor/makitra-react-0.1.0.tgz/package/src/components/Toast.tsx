import * as React from 'react';
import { cx } from '../lib/cx';

export interface ToastAction {
  label: string;
  onClick: () => void;
}

export interface ToastProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Confirms an action in the words of the button that caused it. */
  children: React.ReactNode;
  /** Usually "Undo". */
  action?: ToastAction;
}

/** Render inside a ToastRegion so screen readers announce it. */
export function Toast({ children, action, className, ...rest }: ToastProps) {
  return (
    <div className={cx('mk-toast', className)} {...rest}>
      <span className="mk-toast__text">{children}</span>
      {action ? (
        <button type="button" className="mk-btn mk-btn--quiet" onClick={action.onClick}>
          {action.label}
        </button>
      ) : null}
    </div>
  );
}

export type ToastRegionProps = React.HTMLAttributes<HTMLDivElement>;

/**
 * A polite live region. Keep it mounted and swap toasts inside it,
 * so the announcement isn't lost when the region itself appears.
 */
export function ToastRegion({ className, children, ...rest }: ToastRegionProps) {
  return (
    <div aria-live="polite" className={className} {...rest}>
      {children}
    </div>
  );
}
