import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon } from './Icon';

export interface ChipProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'aria-pressed'> {
  pressed: boolean;
  onPressedChange?: (pressed: boolean) => void;
}

/** A filter toggle. Pressed chips become a plum cut-out with a check. */
export const Chip = React.forwardRef<HTMLButtonElement, ChipProps>(function Chip(
  { pressed, onPressedChange, type = 'button', className, onClick, children, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cx('mk-chip', className)}
      aria-pressed={pressed}
      onClick={(event) => {
        onClick?.(event);
        if (!event.defaultPrevented) onPressedChange?.(!pressed);
      }}
      {...rest}
    >
      <Icon name="check" />
      {children}
    </button>
  );
});

export interface ChipGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Accessible name for the group, such as "Filter recipes". */
  label: string;
}

export function ChipGroup({ label, className, children, ...rest }: ChipGroupProps) {
  return (
    <div role="group" aria-label={label} className={cx('mk-chip-group', className)} {...rest}>
      {children}
    </div>
  );
}
