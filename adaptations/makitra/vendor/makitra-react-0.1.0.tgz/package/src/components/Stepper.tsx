import * as React from 'react';
import { cx } from '../lib/cx';
import { IconButton } from './Button';

export interface StepperProps {
  /** Group name, such as "Servings". Also used for the default button labels. */
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
  /** Formats the visible value, such as (n) => `${n} servings`. */
  format?: (value: number) => React.ReactNode;
  /** Defaults to "Fewer {label}". */
  decrementLabel?: string;
  /** Defaults to "More {label}". */
  incrementLabel?: string;
  className?: string;
}

/** Minus, value, plus. The value is announced politely when it changes. */
export function Stepper({
  label,
  value,
  min = 1,
  max = 99,
  step = 1,
  onChange,
  format,
  decrementLabel,
  incrementLabel,
  className,
}: StepperProps) {
  const noun = label.toLowerCase();
  return (
    <div className={cx('mk-stepper', className)} role="group" aria-label={label}>
      <IconButton
        icon="minus"
        label={decrementLabel ?? `Fewer ${noun}`}
        disabled={value <= min}
        onClick={() => onChange(Math.max(min, value - step))}
      />
      <span className="mk-stepper__value" aria-live="polite">
        {format ? format(value) : value}
      </span>
      <IconButton
        icon="plus"
        label={incrementLabel ?? `More ${noun}`}
        disabled={value >= max}
        onClick={() => onChange(Math.min(max, value + step))}
      />
    </div>
  );
}
