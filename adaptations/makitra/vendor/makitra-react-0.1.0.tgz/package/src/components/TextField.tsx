import * as React from 'react';
import { cx } from '../lib/cx';
import { Icon } from './Icon';

export interface TextFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  /** Visible label above the field. */
  label: React.ReactNode;
  /** Helper text under the field. */
  help?: React.ReactNode;
  /** Says what to enter. Replaces the helper text and marks the field invalid. */
  error?: React.ReactNode;
  /** Class for the wrapping .mk-field. */
  className?: string;
  /** Class for the input itself. */
  inputClassName?: string;
}

/** A labelled text input. The label stays visible above the field; an error says what to enter. */
export const TextField = React.forwardRef<HTMLInputElement, TextFieldProps>(function TextField(
  { label, help, error, id, type = 'text', className, inputClassName, 'aria-describedby': describedBy, ...rest },
  ref,
) {
  const autoId = React.useId();
  const inputId = id ?? autoId;
  const helpId = `${inputId}-help`;
  const hasError = error !== undefined && error !== null && error !== false && error !== '';
  const message = hasError ? error : help;
  const hasMessage = message !== undefined && message !== null && message !== false && message !== '';

  return (
    <div className={cx('mk-field', hasError && 'mk-field--error', className)}>
      <label className="mk-field__label" htmlFor={inputId}>
        {label}
      </label>
      <input
        ref={ref}
        id={inputId}
        type={type}
        className={cx('mk-field__control', type === 'number' && 'mk-num', inputClassName)}
        aria-invalid={hasError || undefined}
        aria-describedby={cx(hasMessage && helpId, describedBy) || undefined}
        {...rest}
      />
      {hasMessage ? (
        <p className="mk-field__help" id={helpId}>
          {message}
        </p>
      ) : null}
    </div>
  );
});

export interface SearchFieldProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type' | 'size'> {
  /** Accessible label, visually hidden. Also the default placeholder. */
  label: string;
  /** Class for the wrapping .mk-search. */
  className?: string;
  inputClassName?: string;
}

/** A search input with a leading search icon and a visually hidden label. */
export const SearchField = React.forwardRef<HTMLInputElement, SearchFieldProps>(function SearchField(
  { label, id, placeholder, className, inputClassName, ...rest },
  ref,
) {
  const autoId = React.useId();
  const inputId = id ?? autoId;
  return (
    <div className={cx('mk-search', className)}>
      <label className="mk-visually-hidden" htmlFor={inputId}>
        {label}
      </label>
      <Icon name="search" />
      <input
        ref={ref}
        id={inputId}
        type="search"
        className={cx('mk-field__control', inputClassName)}
        placeholder={placeholder ?? label}
        {...rest}
      />
    </div>
  );
});
