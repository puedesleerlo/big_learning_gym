import * as React from 'react';
import { cx } from '../lib/cx';

export type DisplaySize = 'xl' | '2xl' | '3xl' | '4xl' | '5xl';

export interface DisplayProps extends React.HTMLAttributes<HTMLElement> {
  /** Element to render. Defaults to h2. */
  as?: React.ElementType;
  /** Maps to --mk-text-{size}. Leave unset to inherit. */
  size?: DisplaySize;
}

/**
 * Hand-cut display type for dish names and screen titles.
 * Protest Guerrilla is Latin-only: pass lang="uk" for Ukrainian text and the CSS
 * switches to heavy, sharp Geologica.
 */
export const Display = React.forwardRef<HTMLElement, DisplayProps>(function Display(
  { as: Component = 'h2', size, className, style, ...rest },
  ref,
) {
  const sizedStyle = size ? { fontSize: `var(--mk-text-${size})`, ...style } : style;
  return React.createElement(Component, {
    ref,
    className: cx('mk-display', className),
    style: sizedStyle,
    ...rest,
  });
});
