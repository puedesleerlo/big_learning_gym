import * as React from 'react';
import { cx } from '../lib/cx';

export type PatchTone = 'soup' | 'preserve' | 'garden' | 'dough' | 'drink' | 'cellar';
export type PatchCut = 'patch' | 'plate' | 'tag';

/**
 * Custom properties for a patch ground: --patch and --on-patch from the category tokens,
 * and --cut only when a cut is given (so component CSS such as .mk-pantry-row__jar keeps its own).
 */
export function patchStyle(tone: PatchTone, cut?: PatchCut): React.CSSProperties {
  return {
    '--patch': `var(--mk-patch-${tone})`,
    '--on-patch': `var(--mk-on-patch-${tone})`,
    ...(cut ? { '--cut': `var(--mk-cut-${cut})` } : null),
  } as React.CSSProperties;
}

export interface PatchProps extends React.HTMLAttributes<HTMLElement> {
  tone: PatchTone;
  cut?: PatchCut;
  /** Element to render. Defaults to div. */
  as?: React.ElementType;
}

/** A paper cut-out ground in a category color. Never put focusable things on it directly. */
export const Patch = React.forwardRef<HTMLElement, PatchProps>(function Patch(
  { tone, cut, as: Component = 'div', className, style, ...rest },
  ref,
) {
  return React.createElement(Component, {
    ref,
    className: cx('mk-patch', className),
    style: { ...patchStyle(tone, cut), ...style },
    ...rest,
  });
});
